const foo = fetch('foo');
