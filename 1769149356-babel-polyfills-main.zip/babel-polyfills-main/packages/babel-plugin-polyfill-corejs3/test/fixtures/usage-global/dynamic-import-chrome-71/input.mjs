const foo = import('foo');
