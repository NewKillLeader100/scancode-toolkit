"".split(foo);

