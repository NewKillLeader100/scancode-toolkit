Symbol.iterator in arr
