function a([b, c]) {}
