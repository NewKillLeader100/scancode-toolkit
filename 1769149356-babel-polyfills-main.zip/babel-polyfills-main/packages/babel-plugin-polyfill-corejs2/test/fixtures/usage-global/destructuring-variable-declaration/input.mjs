const [a, b] = c;
