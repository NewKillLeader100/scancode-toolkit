[a, b] = c;
