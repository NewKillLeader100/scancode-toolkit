Array.from(foo);
